const functions = {
    add: (a, b) => a+b
}